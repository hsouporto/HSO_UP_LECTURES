---
title: 'The Unix Workbench'
tags:
- unix
- linux
- command line
- bash
- git
- cloud
- regular expressions
authors:
- name: Sean Kross
  affiliation: 1
affiliations:
- name: The University of California San Diego
  index: 1
date: 16 March 2018
---

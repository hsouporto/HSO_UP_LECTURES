## 6.6 GitHub

### 6.6.6 Exercises

1. Create a new repository on GitHub. Clone your repository and add a `README.md` file. Push this file to GitHub and create a GitHub Pages website for this repository.

2. Fork an existing repository (try one of mine: https://github.com/seankross) and try to identify something valuable you could contribute. Make changes or additions to that repository, then open a pull request.

3. Read through [GitHub's Guides](https://guides.github.com/).

---
### Solution

- Read [6.6 GitHub](https://seankross.com/the-unix-workbench/git-and-github.html#github) in the The Unix Workbench Book.

## 5.6 Braces

### 5.6.2 Exercises

1. Create 100 text files using brace expansion.

    ```bash
    #!usr/bin/env bash
    # File: ex5-6-q1.sh
    
    touch 100_files/{001..100}.txt
    ```

